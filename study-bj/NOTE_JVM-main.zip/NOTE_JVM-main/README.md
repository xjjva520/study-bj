# NOTE_JVM

> 笔记来源：[尚硅谷JVM全套教程，百万播放，全网巅峰（宋红康详解java虚拟机）](https://www.bilibili.com/video/BV1PJ411n7xZ "尚硅谷JVM全套教程，百万播放，全网巅峰（宋红康详解java虚拟机）")



## 同步更新

- Github：https://github.com/uxiahnan/NOTE_JVM
- Gitee：https://gitee.com/vectorx/NOTE_JVM
- CC：https://codechina.csdn.net/qq_35925558/NOTE_JVM



## 其他平台

- 语雀：[JVM从入门到精通 · 语雀 (yuque.com)](https://www.yuque.com/u21195183/jvm)
- 博客园：[《JVM从入门到精通》导航 - VectorX - 博客园 (cnblogs.com)](https://www.cnblogs.com/vectorx/p/14732612.html)
- CSDN：[JVM_VectorX's Blog-CSDN博客](https://blog.csdn.net/qq_35925558/category_11010855.html)
- 掘金：[JVM从入门到精通 - VectorX的专栏 - 掘金 (juejin.cn)](https://juejin.cn/column/6960637035375755294)




:sparkles:另外，新搭建了一个Github Pages网站，大家可以去尝尝鲜~

- 我的博客:link:：[标签 | VectorX (vectorxxxx.github.io)](https://vectorxxxx.github.io/tags/#15-html5css3)



<mark>**整理不易，还望各位看官一键三连 :heart: :heart: :heart: **</mark>

<mark>**整理不易，还望各位看官一键三连 :heart: :heart: :heart: **</mark>

<mark>**整理不易，还望各位看官一键三连 :heart: :heart: :heart: **</mark>



整理难免有疏忽和遗漏的地方，欢迎大家指正批评！



> 署名 4.0 国际 (CC BY 4.0)。您可以自由地：共享 — 在任何媒介以任何形式复制、发行本作品；演绎 — 修改、转换或以本作品为基础进行创作；在任何用途下，甚至商业目的。只要你遵守许可协议条款，许可人就无法收回你的这些权利。惟须遵守下列条件：署名 — 您必须给出适当的署名，提供指向本许可协议的链接，同时标明是否（对原始作品）作了修改。您可以用任何合理的方式来署名，但是不得以任何方式暗示许可人为您或您的使用背书。



---



## 2021-07-12 更新

- 处理图床屏蔽造成的图片链接失效的问题

## 2021-06-14 更新

- 利用README机制调整了目录结构，方便大家直接在托管平台阅读

